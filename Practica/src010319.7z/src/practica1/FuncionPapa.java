package practica1;

import common.Cromosoma;

public abstract class  FuncionPapa {

	public abstract double Evalua(Cromosoma ind_evaluar);
	public abstract void Set_Function();
}
