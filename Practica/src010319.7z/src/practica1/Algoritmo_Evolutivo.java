package practica1;

import common.Cromosoma;
import common.Mutacion_I;
import common.Poblacion;
import common.cruce.Reproduccion_I;
import common.evaluacion.Function_Controller;
import common.evaluacion.Function_main;
import common.seleccion.FactoriaSeleccion;
import common.seleccion.Seleccion;
import interfaz.controlador.Controlador;

public class Algoritmo_Evolutivo {
	private Poblacion Pobl_principal;
	private FuncionPapa fp;
	private Cromosoma mejor;
	private Seleccion Seleccion_I;
	private int generaciones;
	private boolean flag_print = true;
	private int tamElite = 2;
	
	public Algoritmo_Evolutivo(int tipo, int tpobl, int generaciones, double elite, String selec) {
//		Function_Controller.setF_actual(0); // permite seleccionar la funcion pasandole un indice
		this.fp = Function_Controller.getF_actual();
		this.fp.Set_Function();
		this.Pobl_principal = new Poblacion(tipo, tpobl, 0);
		this.generaciones = generaciones;
		this.mejor = Pobl_principal.getIndividuos(0);
		this.tamElite = (int)(tpobl*elite/100);
		Seleccion_I = FactoriaSeleccion.getAlgoritmoDeSeleccion(selec);
	}

	@Override
	public String toString() {
		String rtn = "";
		for(int i = 0; i<Pobl_principal.getTpobl();i++) {
			rtn += (Pobl_principal.getIndividuos(i).toString() + "\n");
		}
		return rtn;
	}
	
	public void evalua() {
		double suma_aptitud = 0;
		for(int i = 0; i<Pobl_principal.getTpobl();i++) {
			Pobl_principal.getIndividuos(i).setApt(fp.Evalua(Pobl_principal.getIndividuos(i)));
			
			/*if(Pobl_principal.getIndividuos(i).compareTo(this.mejor) > 1) {
				this.mejor = new Cromosoma(Pobl_principal.getIndividuos(i));
			}*/
			
			if(!Function_main.MAX_MIN) {
				if(Pobl_principal.getIndividuos(i).getApt() > this.mejor.getApt()) {
					this.mejor = new Cromosoma(Pobl_principal.getIndividuos(i));
				}
			} else {
				if(Pobl_principal.getIndividuos(i).getApt() < this.mejor.getApt()) {
					this.mejor = new Cromosoma(Pobl_principal.getIndividuos(i));
				}
			}
			suma_aptitud += Pobl_principal.getIndividuos(i).getApt();
		}
		
		for(int i = 0; i<Pobl_principal.getTpobl();i++) {
			Pobl_principal.getIndividuos(i).setPunt(Pobl_principal.getIndividuos(i).getApt()/suma_aptitud);
		}
		
		Pobl_principal.calcularMejor();
		Pobl_principal.calcularPunt_Acum();
	}
	
	public void selecciona_cruza() {
		Pobl_principal = Seleccion_I.execute(Pobl_principal);
		if(flag_print == true) {
			System.out.println("\n POST-SELECCION: ----------------------- generacion:  -----------------------\n\n");
			System.out.println(toString());
			
		}
		if(Main.tipo == 0) {
			Reproduccion_I.reproduccion.Seleccion_Cruce_Padres_1p(Pobl_principal);
		}else {
			Reproduccion_I.reproduccion.Seleccion_Cruce_Padres_real_basico(Pobl_principal);
		}
		
	}
	
	public void muta() {
		int j2 = Pobl_principal.getIndividuos(0).getGenes_size();
		for(int i = 0; i<Pobl_principal.getTpobl(); i++) {		
				for(int z=0; z < Pobl_principal.getIndividuos(i).getGenes_size() ; z++) {
					if(Main.tipo == 0) {
					Mutacion_I.mutacion.mutacionBasica(Pobl_principal.getIndividuos(i), z);
					}else {
					Mutacion_I.mutacion.mutacion_real_NOuniforme(Pobl_principal.getIndividuos(i), z);
					}
				}
			}
		}
				
	
	public boolean terminado() {
		return this.generaciones < Pobl_principal.getGeneracion();
	}
	
	public String exe(Controlador ctrl) {
		Cromosoma[] elite;
		
		if(flag_print == true) {
			System.out.println("\n PRIMERA GENERACION: ----------------------- generacion:  -----------------------\n\n");
			System.out.println(toString());			
		}
		
		evalua();
		ctrl.update(mejor, Pobl_principal.getMejor(), Pobl_principal.getGeneracion());
		if(flag_print == true) {
			System.out.println("\n POST-EVALUACION: ----------------------- generacion: 0 -----------------------\n\n");
			System.out.println(toString());			
		}
		
		for(int i = 0 ; i<this.generaciones ; i++) {
			elite = Pobl_principal.separaMejores(tamElite);
			if(flag_print == true) {
				System.out.println("\n ELITE: ----------------------- generacion: " + i + " -----------------------\n\n");
				for(Cromosoma c : elite)
					System.out.println(c.toString());			
			}
			selecciona_cruza();
			if(flag_print == true) {
				System.out.println("\n POST-CRUCE: ----------------------- generacion: " + i + " -----------------------\n\n");
				System.out.println(toString());			
			}
			muta();
			if(flag_print == true) {
				System.out.println("\n POST-MUTACION: ----------------------- generacion: " + i + " -----------------------\n\n");
				System.out.println(toString());	
			}
			
			Pobl_principal.incluye(elite);
			
			evalua();
			if(flag_print == true) {
				System.out.println("\n POST-EVALUACION: ----------------------- generacion: " + i + " -----------------------\n\n");
				System.out.println(toString());			
			}
			
			ctrl.update(mejor, Pobl_principal.getMejor(), Pobl_principal.getGeneracion());
		}
		return "EL MEJOR ES:" + mejor.toString();
	}
}
