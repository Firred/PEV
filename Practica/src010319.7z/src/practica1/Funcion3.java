package practica1;

import common.Cromosoma;
import common.evaluacion.Function_main;

public class Funcion3 extends FuncionPapa{
	public Funcion3() {
		Set_Function();
	}

	public void Set_Function() {
		Function_main.Set_Arrays(2);
		for (int i = 0; i<2; i++) {
			Function_main.MAX[i] = 10;
			Function_main.MIN[i] = -10;
			Function_main.PRECISION[i] = 0.0001;
		}
	}
	
	@Override
	public double Evalua(Cromosoma ind_evaluar) {
		double g0 = ind_evaluar.getGen(0).getCaracteristica();
		double g1 = ind_evaluar.getGen(1).getCaracteristica();
		double int1 = 0;
		double int2 = 0;
		for(int i= 0; i< 2; i++) {
			for(int j = 1;j<5;j++) {
				int1 += (i*Math.cos((i+1)*g0+i));
				int2 += (i*Math.cos(i+1)*g1+i);
			}
		}
		return int1*int2;
	}
}
