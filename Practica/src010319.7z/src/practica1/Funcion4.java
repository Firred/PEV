package practica1;

import common.Cromosoma;
import common.evaluacion.Function_main;

public class Funcion4 extends FuncionPapa{
	
	public Funcion4() {
		Set_Function();
	}

	public void Set_Function() {
		Function_main.Set_Arrays(7);
		for (int i = 0; i<7; i++) {
			Function_main.MAX[i] = 0;
			Function_main.MIN[i] = Math.PI;
			Function_main.PRECISION[i] = 0.0001;
		}
	}
	
	@Override
	public double Evalua(Cromosoma ind_evaluar) {
		int int1 = 0;
		double[] g = new double[ind_evaluar.getGenes_size()];
		for(int j = 0 ; j< ind_evaluar.getGenes_size() ; j++) {
			g[j] = ind_evaluar.getGen(j).getCaracteristica();
			for(int i =0 ; i<7; i++) {
				int1 += Math.sin(g[j])*Math.pow(20, Math.sin((i+1)*Math.pow(2, g[i])/Math.PI));
			}
		}
		
		return -int1;
	}
}
