package common.cruce;

import java.util.Random;

import common.Cromosoma;

public class Par_Cromosomas_C {
	private Cromosoma c1;
	private Cromosoma c2;
	private Random rand = new Random();
	
	/** GETTERS
	 * @return cromosoma 1
	 */
	public Cromosoma getC1() {
		return c1;
	}
	/**
	 * @return cromosoma 2
	 */
	public Cromosoma getC2() {
		return c2;
	}
	
	/** SETTERS
	 * @param c1 cromosoma 1
	 */
	public void setC1(Cromosoma c1) {
		this.c1 = c1;
	}
	
	/**
	 * @param c2 cromosoma 2
	 */
	public void setC2(Cromosoma c2) {
		this.c2 = c2;
	}
	
	/** FUNCIONES
	 * Dandole el punto de la fusion junta a dos genes de tipo Boolean[]
	 * @param punto_merge
	 * @return
	 */
	protected Par_Cromosomas_C merge_1p(int punto_merge, Par_Cromosomas_C P_1_2, int pos) {
			for (int i = 0; i<punto_merge; i++) {
				this.getC1().setAleloBi_1g(P_1_2.getC2().getGenes_Bool(i, pos), i, pos);
				this.getC2().setAleloBi_1g(P_1_2.getC1().getGenes_Bool(i, pos), i, pos);
			}
			
			for (int i = punto_merge; i<P_1_2.getC1().getGen(pos).getLong_gen(); i++) {
				this.getC1().setAleloBi_1g(P_1_2.getC1().getGenes_Bool(i, pos), i, pos);
				this.getC2().setAleloBi_1g(P_1_2.getC2().getGenes_Bool(i, pos), i, pos);
			}
			
			this.getC1().getGen(pos).calcularCaracteristica(pos);
			this.getC2().getGen(pos).calcularCaracteristica(pos);
		return this;
	}
	
	/** Cruce punto a punto en binario
	 * @return
	 */
	protected Par_Cromosomas_C merge_xp_1g(int pos) {
		for (int i = 0; i<this.getC1().getGenes_long(); i++) {
			boolean z = true;
			if(rand.nextDouble()>0.5) {
				z = this.getC1().getGenes_Bool(i, pos);
				this.getC1().setAleloBi_1g(this.getC2().getGenes_Bool(i, pos), i, pos);
				this.getC2().setAleloBi_1g(z, i, pos);
			}
		}
		return this;
	}
	
	
	/** Cruce punto a punto en binario
	 * @return
	 */
	protected void merge_real_basico(Par_Cromosomas_C P_1_2, int pos) {
		this.getC1().getGen(pos).setAlelo((P_1_2.getC1().getGen(pos).getAlelo()+P_1_2.getC2().getGen(pos).getAlelo())/2);
		this.getC2().getGen(pos).setAlelo((P_1_2.getC2().getGen(pos).getAlelo()+P_1_2.getC1().getGen(pos).getAlelo())/2);		
	}
	
	
}

