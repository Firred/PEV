package common.cruce;

import java.util.Random;

import common.Cromosoma;

public class Cruce{
	private int num_sele_cruce;
	//private Par_Cromosomas_C H_1_2 = new Par_Cromosomas_C();
	private Random rand = new Random(); // Punto de cruce
	
	public Par_Cromosomas_C cruce_1p(Par_Cromosomas_C P_1_2, Par_Cromosomas_C H_1_2, int pos){
		//H_1_2.setC1(new Cromosoma(P_1_2.getC1()));
		//H_1_2.setC2(new Cromosoma(P_1_2.getC2()));
		int n = P_1_2.getC1().getGen(pos).getLong_gen();
		n = rand.nextInt(Math.abs(n));
		H_1_2 = H_1_2.merge_1p(n, P_1_2, pos);
		return H_1_2;
	}
	
	public Par_Cromosomas_C cruce_real_aritmetico(Par_Cromosomas_C P_1_2, int pos) {
		Par_Cromosomas_C H_1_2 = new Par_Cromosomas_C();
		H_1_2 = P_1_2;
		H_1_2.merge_real_basico(P_1_2, pos);
		return H_1_2;		
	}
}
