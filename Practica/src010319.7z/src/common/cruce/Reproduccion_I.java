package common.cruce;

public interface Reproduccion_I {
	final Reproduccion reproduccion = new Reproduccion();
}
