package common.cruce;

import java.util.Random;

import common.Cromosoma;
import common.Poblacion;

public class Reproduccion implements Cruce_I{ 
	private boolean flag;
	private double prob_cruce = 0.6;
	//private Par_Cromosomas_C P_1_2 = new Par_Cromosomas_C();
	Random rand = new Random();
	
	/** Dandole una poblacion los empareja con la % de cruce y los junta en un punto
	 * Reemplazando padres por hijos
	 * @param pobl_seleccion
	 * @return
	 */
	public Poblacion Seleccion_Cruce_Padres_1p(Poblacion pobl_seleccion) {
		Poblacion newPobl = new Poblacion();
		Par_Cromosomas_C P_1_2 = new Par_Cromosomas_C();
		//int np1 = 0;
		//int np2 = 0;
		this.flag = false;
		Par_Cromosomas_C H_1_2 = new Par_Cromosomas_C();
		
		for(int i = 0; i < pobl_seleccion.getTpobl(); i++) {
			if(prob_cruce >= rand.nextDouble()) {
				if(this.flag == false) {
					P_1_2.setC1(new Cromosoma(pobl_seleccion.getIndividuos(i)));
					//np1 = i;
					this.flag = true;
					H_1_2.setC1(new Cromosoma(P_1_2.getC1()));
				}else{
					P_1_2.setC2(new Cromosoma(pobl_seleccion.getIndividuos(i)));
					//np2 = i;
					this.flag = false;
					H_1_2.setC2(new Cromosoma(P_1_2.getC2()));
					for(int j = 0; j < pobl_seleccion.getIndividuos(i).getGenes_size(); j++) {
						H_1_2 = Cruce_I.cruce.cruce_1p(P_1_2, H_1_2, j);
					}

					newPobl.addIndividuo(H_1_2.getC1());
					newPobl.addIndividuo(H_1_2.getC2());
				}				
			}
			else {
				newPobl.addIndividuo(pobl_seleccion.getIndividuos(i));
			}
		}
		return 	pobl_seleccion;
	}
	
	/** Dandole una poblacion los empareja con la % de cruce y los junta en un punto
	 * Reemplazando padres por hijos
	 * @param pobl_seleccion
	 * @return
	 */
	public Poblacion Seleccion_Cruce_Padres_real_basico(Poblacion pobl_seleccion) {
		Par_Cromosomas_C P_1_2 = new Par_Cromosomas_C();
		int np1 = 0;
		int np2 = 0;
		this.flag = false;
		int n = pobl_seleccion.getTpobl();
		for(int i = 0; i < n ; i++) {
			if(prob_cruce >= rand.nextDouble()) {
				if(this.flag == false) {
					P_1_2.setC1(pobl_seleccion.getIndividuos(i));
					np1 = i;
					this.flag = true;
				}else{
					P_1_2.setC2(pobl_seleccion.getIndividuos(i));
					np2 = i;
					this.flag = false;
					for(int j = 0; j < pobl_seleccion.getIndividuos(i).getGenes_size(); j++) {
						P_1_2 = Cruce_I.cruce.cruce_real_aritmetico(P_1_2, j);
					}
					pobl_seleccion.setIndividuos(P_1_2.getC1(), np1);
					pobl_seleccion.setIndividuos(P_1_2.getC2(), np2);
				}				
			}
		}
		return 	pobl_seleccion;
	}
	
}
