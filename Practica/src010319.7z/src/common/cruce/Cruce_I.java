package common.cruce;

public interface Cruce_I {
	final Cruce cruce = new Cruce();
	
}
