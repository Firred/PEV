package common.seleccion;

import common.Poblacion;

public interface Seleccion {
	public Poblacion execute(Poblacion pobl);
}
