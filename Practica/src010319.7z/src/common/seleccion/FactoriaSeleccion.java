package common.seleccion;

import common.seleccion.estocastico.MuestreoEstocasticoUniversal;
import common.seleccion.estocastico.SeleccionRuleta;
import common.seleccion.torneo.TorneoDeterministico;
import common.seleccion.torneo.TorneoProbabilistico;

public class FactoriaSeleccion {
	private final static Seleccion[] TIPOS = { 
			new SeleccionRuleta(), 
			new TorneoDeterministico(), 
			new TorneoProbabilistico(), 
			new Truncamiento(),
			new MuestreoEstocasticoUniversal(),
			new  Ranking()
	};
	
	public static Seleccion getAlgoritmoDeSeleccion(String algoritmo) {
		switch(algoritmo) {
			case "Ruleta":
				return TIPOS[0];
			case "Torneo_Deterministico":
				return TIPOS[1];
			case "Torneo_Probabilistico":
				return TIPOS[2];
			case "Truncamiento":
				return TIPOS[3];
			case "Estoc�stico":
				return TIPOS[4];		
			case "Ranking":
				return TIPOS[5];
			default:
				return TIPOS[0];
		}
	}
	
}
