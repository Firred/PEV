package common;

import java.util.Random;

import common.evaluacion.Function_main;
import common.genes.Gen;
import common.genes.GenBi;

public class Mutacion {
	private double Tmutacion = 0.02;
	private Random Rand = new Random();
	private int mut_failed = 0;
	
	public void mutacionBasica(Cromosoma indiviudo, int pos) {
		for(int j=0;j<indiviudo.getGen(pos).getLong_gen();j++) {
			if(Tmutacion > Rand.nextDouble()) {
				indiviudo.setAleloBi_1g(!indiviudo.getGenes_Bool(j, pos), j , pos);
				indiviudo.getGen(pos).calcularCaracteristica(pos);
			}
		}
	}
	
	public void mutacion_real_NOuniforme(Cromosoma individuo, int pos) {
		double checkpoint = 0;
		double next_mut = 0;
		if(Tmutacion > Rand.nextDouble()){
			next_mut = Rand.nextDouble() * (Rand.nextBoolean() ? 1 : -1);
			// Permite realizar una mutacion desde -1 hasta 1
			checkpoint = individuo.getGen(pos).getAlelo()+next_mut; 			
			if(checkpoint > Function_main.MAX[pos] || checkpoint < Function_main.MIN[pos] ) {
				mut_failed++;
				System.out.println("Mutacion no valida: " + mut_failed);
			} else {
				individuo.getGen(pos).setAlelo(checkpoint);
			}
		}
		
	}
	
}
