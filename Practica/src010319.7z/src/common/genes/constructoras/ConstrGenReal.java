package common.genes.constructoras;

import common.genes.Gen;

public class ConstrGenReal implements ConstrGen {

	@Override
	public Gen construir(double min, double max, double precision) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean[] getalelo(int n1, int n2) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean[] getAlelo() {
		// TODO Auto-generated method stub
		return null;
	}

}
