package common.genes.constructoras;

import common.genes.Gen;
import common.genes.GenBi;
/*
public class ConstrGenBi implements ConstrGen{
	/** CONSTRUCTORES
	 *  constructor por defecto
	 */
/*
	public ConstrGenBi() {}

	/** FUNCIONES
	 *  Constructor de genes de genes
	 * @param min
	 * @param max
	 * @param precision
	 * @return devuelve un nuevo genBinario
	 * @see common.genes.constructoras.ConstrGen#construir(double, double, double)
	 */
/*
	@Override

	public Gen construir(double min, double max, double precision) {
		return new GenBi(min, max, precision);
	}

	@Override
	public Boolean[] getalelo(int n1, int n2) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean[] getAlelo() {
		// TODO Auto-generated method stub
		return null;
	}

}
*/	