package common.genes;

public class Gen {

	private double caracteristica; //Caracteristica que representa el alelo del gen
	protected int long_gen;
	private GenController controller;
	
	/** CONSTRUCTORES
	 * 
	 */		
	protected Gen() {}
	
	protected Gen(int n) {
		this.long_gen = n;
	}
	
	public Gen(Gen g) {
		this.caracteristica = g.caracteristica;
		this.long_gen = g.long_gen;
		this.controller = g.controller;
	}
		
	
	/** GETTERS
	 * @return caracteristica
	 */
	public double getCaracteristica() {
		return caracteristica;
	}

	/**
	 * @return longitud del gen
	 */
	public int getLong_gen() {
		return long_gen;
	}
	
	/** SETTERS
	 * @param c valor caracteristica
	 */
	void setCarateristica(double c) {
		caracteristica = c;
	}

	/**
	 * @param tipo
	 * @return
	 */
	public Gen generarGen(int tipo, int z) {
		return controller.generarGen(tipo,z);	
	}

	public void setAlelo(double valor) {
		controller.setAlelo(valor);
	}
	
	public double getAlelo() {
		return controller.getAlelo();
	}
	
	@Override
	public String toString() {
		return "Gen [caracteristica=" + caracteristica + ", long_gen=" + long_gen + "]";
	}

	public void calcularCaracteristica(int pos) {
		// TODO Auto-generated method stub
		
	}

}
