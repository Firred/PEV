package common;

public interface Mutacion_I {
	final Mutacion mutacion = new Mutacion();
}
