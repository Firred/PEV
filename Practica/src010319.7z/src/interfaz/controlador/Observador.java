package interfaz.controlador;

import common.Cromosoma;
import common.Poblacion;

public interface Observador {
	public void update(Cromosoma mejorG, Cromosoma mejorP, int gen);
}
