package interfaz.controlador;

public class Opcion {
	int pobl;
	int generaciones;
	double cruces;
	double muta;
	double prec;
	double elite;
	String selec;
	int func;
	
	public Opcion(int pobl, int gener, double cruces, double muta, double prec, double elite, String selec, int func) {
		this.pobl = pobl;
		this.generaciones = gener;
		this.cruces = cruces;
		this.muta = muta;
		this.prec = prec;
		this.elite = elite;
		this.selec = selec;
		this.func = func;
	}
}
