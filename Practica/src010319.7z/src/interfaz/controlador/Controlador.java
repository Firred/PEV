package interfaz.controlador;

import java.util.ArrayList;

import common.Cromosoma;
import common.Poblacion;
import common.evaluacion.Function_Controller;
import common.evaluacion.Function_main;
import practica1.Algoritmo_Evolutivo;

public class Controlador {
	
	private ArrayList<Observador> obs = new ArrayList<>();
	
	public void execute(Opcion op) {
		int tipo = 0;

		if(op != null) {
			System.out.println(op.selec);
			Function_Controller.setF_actual(op.func);

			Algoritmo_Evolutivo ag = new Algoritmo_Evolutivo(tipo, op.pobl, op.generaciones, op.elite, op.selec);
			
			System.out.println(ag.exe(this));
		}
	}
	
	public void addObservador(Observador obs) {
		this.obs.add(obs);
	}
	
	public void update(Cromosoma mejorG, Cromosoma mejorP, int gen) {
		for (Observador o : this.obs) {
			o.update(mejorG, mejorP, gen);
		}
	}
}
