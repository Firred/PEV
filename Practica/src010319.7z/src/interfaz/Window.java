package interfaz;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import interfaz.controlador.Controlador;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.swt.widgets.Canvas;

public class Window {

	protected Shell shell;
	private Controlador ctrl = new Controlador();
	private final FormToolkit formToolkit = new FormToolkit(Display.getDefault());

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			Window window = new Window();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setSize(650, 575);
		shell.setText("SWT Application");
		//OpcionesPanel op = new OpcionesPanel();
		Opciones op = new Opciones(shell, SWT.None);
		op.setBounds(0, 51, 174, 242);
		Menu menu = new Menu(shell, SWT.NONE, ctrl, op);
		menu.setBounds(0, 10, 434, 35);
		
		Composite composite = new Composite(shell, SWT.NONE);
		composite.setBounds(180, 10, 444, 283);
		formToolkit.adapt(composite);
		formToolkit.paintBordersFor(composite);
		
		Canvas canvas = new Canvas(composite, SWT.NONE);
		canvas.setBounds(10, 10, 360, 225);
		formToolkit.adapt(canvas);
		formToolkit.paintBordersFor(canvas);
		
		
	//	Grafica grafica = new Grafica(shell, SWT.NONE);
		//grafica.setBounds(180, 51, 444, 475);
		//PanelGrafica graf = new PanelGrafica();
		//graf.setBounds(180, 51, 548, 515);
	}
}
