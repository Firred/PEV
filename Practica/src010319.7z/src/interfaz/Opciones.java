package interfaz;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.forms.widgets.FormToolkit;

import interfaz.controlador.Opcion;

import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

public class Opciones extends Composite {

	private final FormToolkit toolkit = new FormToolkit(Display.getCurrent());
	private Text textPobl;
	private Text textGen;
	private Text textCruces;
	private Text textMut;
	private Text textPrec;
	private Text textElitismo;
	Combo comboSelec;
	Combo comboFunc;

	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public Opciones(Composite parent, int style) {
		super(parent, SWT.BORDER | SWT.EMBEDDED);
		addDisposeListener(new DisposeListener() {
			public void widgetDisposed(DisposeEvent e) {
				toolkit.dispose();
			}
		});
		toolkit.adapt(this);
		toolkit.paintBordersFor(this);
		setLayout(new GridLayout(2, false));
		
		Label lblNewLabel = new Label(this, SWT.NONE);
		lblNewLabel.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblNewLabel, true, true);
		lblNewLabel.setText("Poblaci\u00F3n");
		
		textPobl = new Text(this, SWT.BORDER);
		textPobl.setText("100");
		textPobl.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, true, false, 1, 1));
		toolkit.adapt(textPobl, true, true);
		
		Label lblNewLabel_1 = new Label(this, SWT.NONE);
		lblNewLabel_1.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblNewLabel_1, true, true);
		lblNewLabel_1.setText("Generaciones");
		
		textGen = new Text(this, SWT.BORDER);
		textGen.setText("100");
		textGen.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, true, false, 1, 1));
		toolkit.adapt(textGen, true, true);
		
		Label lblNewLabel_2 = new Label(this, SWT.NONE);
		lblNewLabel_2.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblNewLabel_2, true, true);
		lblNewLabel_2.setText("Cruces");
		
		textCruces = new Text(this, SWT.BORDER);
		textCruces.setText("0.6");
		textCruces.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, true, false, 1, 1));
		toolkit.adapt(textCruces, true, true);
		
		Label lblMutaciones = new Label(this, SWT.NONE);
		lblMutaciones.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblMutaciones, true, true);
		lblMutaciones.setText("Mutaciones");
		
		textMut = new Text(this, SWT.BORDER);
		textMut.setText("0.1");
		textMut.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, true, false, 1, 1));
		toolkit.adapt(textMut, true, true);
		
		Label lblPrecisin = new Label(this, SWT.NONE);
		lblPrecisin.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblPrecisin, true, true);
		lblPrecisin.setText("Precisi\u00F3n");
		
		textPrec = new Text(this, SWT.BORDER);
		textPrec.setText("0.001");
		textPrec.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, true, false, 1, 1));
		toolkit.adapt(textPrec, true, true);
		
		Label lblElitismo = new Label(this, SWT.NONE);
		lblElitismo.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblElitismo, true, true);
		lblElitismo.setText("Elitismo");
		
		Button button = new Button(this, SWT.CHECK);
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				textElitismo.setVisible(true^textElitismo.isVisible());
			}
		});
		button.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(button, true, true);
		new Label(this, SWT.NONE);
		
		textElitismo = new Text(this, SWT.BORDER);
		textElitismo.setText("2");
		textElitismo.setVisible(false);
		textElitismo.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, true, false, 1, 1));
		toolkit.adapt(textElitismo, true, true);
		
		Label lblSeleccion = new Label(this, SWT.NONE);
		lblSeleccion.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblSeleccion, true, true);
		lblSeleccion.setText("Selecci\u00F3n");
		
		comboSelec = new Combo(this, SWT.NONE);
		comboSelec.setItems(new String[] {"Ruleta", "Estoc\u00E1stico", "Torneo Determin\u00EDstico", "Torneo Probabil\u00EDstico", "Ranking", "Truncamiento"});
		comboSelec.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, true, false, 1, 1));
		toolkit.adapt(comboSelec);
		toolkit.paintBordersFor(comboSelec);
		comboSelec.select(0);
		
		Label lblFuncin = new Label(this, SWT.NONE);
		lblFuncin.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, false, false, 1, 1));
		toolkit.adapt(lblFuncin, true, true);
		lblFuncin.setText("Funci\u00F3n");
		
		comboFunc = new Combo(this, SWT.NONE);
		comboFunc.setItems(new String[] {"1", "2", "3", "4", "5"});
		comboFunc.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, true, false, 1, 1));
		toolkit.adapt(comboFunc);
		toolkit.paintBordersFor(comboFunc);
		comboFunc.select(0);

	}

	public Opcion getOpciones() {
		try {
			double elit;
			if(!textElitismo.isVisible())
				elit = 0;
			else 
				elit = Double.parseDouble(this.textElitismo.getText());
			return new Opcion(Integer.parseInt(this.textPobl.getText()), Integer.parseInt(this.textGen.getText()),
					Double.parseDouble(this.textCruces.getText()), Double.parseDouble(this.textMut.getText()), 
					Double.parseDouble(this.textPrec.getText()), elit, (String)this.comboSelec.getText(), this.comboFunc.getSelectionIndex());
		}
		catch (Exception e) {
			return null;
		}
		
}
}
