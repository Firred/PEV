package interfaz;

import javax.swing.JFrame;
import javax.swing.JPanel;

import org.math.plot.Plot2DPanel;

import common.Cromosoma;
import common.Poblacion;
import interfaz.controlador.Observador;

public class PanelGrafica extends Plot2DPanel implements Observador {

	private double[] x;
	private double[] y;
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Create the panel.
	 */
	public PanelGrafica(int generaciones) {
		super();
		
		x = new double[generaciones];
		y = new double[generaciones];
		for(int i = 0; i < generaciones; i++)
			y[i] = i;
		
	//	double[] x = { 1, 2, 3, 4, 5, 6 };
		//double[] y = { 45, 89, 6, 32, 63, 12 };
		
		// create your PlotPanel (you can use it as a JPanel)
		//Plot2DPanel plot = new Plot2DPanel();
		
		// define the legend position
		this.addLegend("SOUTH");
		
		// add a line plot to the PlotPanel
		this.addLinePlot("my plot", x, y);
		
		// put the PlotPanel in a JFrame like a JPanel
		//JFrame frame = new JFrame("a plot panel");
		//frame.setSize(600, 600);
		//frame.setContentPane(plot);
		//frame.setVisible(true);
	}

	@Override
	public void update(Cromosoma mejorG, Cromosoma mejorP, int gen) {
		x[gen] = mejorG.getApt();
		
		this.addLinePlot("my plot", x, y);
	}

}